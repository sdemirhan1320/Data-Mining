getwd()
setwd("C:/Users/Sinan/Desktop/HW3")
data<-read.csv("EastWestAirlines.csv",header = TRUE)
library(class)
library(CRAN)
library(cluster)
library(purrr)
library(factoextra)
library(dplyr)
library(tidyr)
library(ggplot2)
#The goal is to try to identify clusters of passengers that have similar 
#charactersitics for the purpose of targeting different segments for different 
#types of mileage offers.

# a. Apply hierarchical clustering with Euclidean distance 
# and complete linkage. How many clusters appear to be appropriate?
fix(data)
data=data[,2:12]
data_scaled<-scale(data)

d <- dist(data_scaled, method = "euclidean")
hc1 <- hclust(d, method = "complete")
cl2<-cutree(hc1,k=2)
sil2=silhouette (cl2, d)
plot(sil2)
cl3<-cutree(hc1,k=3)
sil3=silhouette (cl3, d)
plot(sil3)
cl4<-cutree(hc1,k=4)
sil4=silhouette (cl4, d)
plot(sil)
cl5<-cutree(hc1,k=5)
sil5=silhouette (cl5, d)
plot(sil5)
cl6<-cutree(hc1,k=6)
sil6=silhouette (cl6, d)
plot(sil6)
plot(hc1, cex = 0.05, hang = -1)
rect.hclust(hc1, k = 2)



# b. Compare the cluster centroids to characterize the different clusters and try to 
# give each cluster a label.
g24=cutree(hc1, k =5)
table(g24)
hc1
clust <- cutree(hc1, k = 15)
fviz_cluster(list(data = data, cluster = clust))

# c. To check the stability of the clusters, remove a random 
# 5% of the data (by taking a random sample of 95% of the records, namely 200 records),
# and repeat the analysis. Does the same picture emerge? Use 425 as the seed.
set.seed(425)
train=sample(1:3999,200)
train
random_data=data[train,]

scaled_rand<-scale(random_data)
rand_dist <- dist(scaled_rand, method = "euclidean")
hc2 <- hclust(rand_dist, method = "complete" )

randcl2<-cutree(hc2,k=2)
sil_rand2=silhouette (randcl2, rand_dist)
plot(sil_rand2)

randcl3<-cutree(hc2,k=3)
sil_rand3=silhouette (randcl3, rand_dist)
plot(sil_rand3)

randcl4<-cutree(hc2,k=4)
sil_rand4=silhouette (randcl4, rand_dist)
plot(sil_rand4)

plot(hc2, cex = 0.6, hang = -1)

# d. Use k-means algorithm with the number of clusters you
# found in part (a). Does the same picture emerge?

kmeans2<-kmeans(data_scaled,centers =2,nstart = 120 )
sil.kmeans2<-silhouette(kmeans2$cl,dist(data))
plot(sil.kmeans2)

kmeans3<-kmeans(data_scaled,centers =3,nstart = 120 )
sil.kmeans3<-silhouette(kmeans3$cl,dist(data))
plot(sil.kmeans3)

kmeans4<-kmeans(data_scaled,centers =4,nstart = 120 )
sil.kmeans4<-silhouette(kmeans4$cl,dist(data))
plot(sil.kmeans4)

kmeans5<-kmeans(data_scaled,centers =5,nstart = 120 )
sil.kmeans5<-silhouette(kmeans5$cl,dist(data))
plot(sil.kmeans5)

kmeans6<-kmeans(data_scaled,centers =6,nstart = 120 )
sil.kmeans6<-silhouette(kmeans6$cl,dist(data))
plot(sil.kmeans6)

kmeans7<-kmeans(data_scaled,centers =7,nstart = 120 )
sil.kmeans7<-silhouette(kmeans7$cl,dist(data))
plot(sil.kmeans7)

# e. Which clusters would you target for offers, and 
# what type of offers would you target to customers in that cluster?
  






